﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ASSIGNMENT2_DATABASE_CONNECTION
{
    public partial class USER_DATA : Form
    {
        SqlConnection sqlConnection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=local_db_connect;Integrated Security=True");

        public USER_DATA()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into [user_details](NAME,SURNAME,ADDRESS,USERNAME,PASSWORD)values('" + textBox1.Text + "','" + textBox2.Text + "','" 
                + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
            cmd.ExecuteNonQuery();
            sqlConnection.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            Dispaly_data();
            MessageBox.Show("Data inserted successfully");
        }
        public void Dispaly_data()
        {
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [user_details]";
            cmd.ExecuteNonQuery();
            DataTable data = new DataTable();
            SqlDataAdapter dt = new SqlDataAdapter(cmd);
            dt.Fill(data);
            dataGridView1.DataSource = data;
            sqlConnection.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from [user_details] where Name='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            sqlConnection.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            Dispaly_data();
            MessageBox.Show("Data deleted successfully");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update [user_details] set Name='" + textBox2.Text + "' where Name='" + textBox1.Text + "'";
            cmd.ExecuteNonQuery();
            sqlConnection.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            Dispaly_data();
            MessageBox.Show("Data updated successfully");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Dispaly_data();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [user_details] where Name='" + textBox6.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            sqlConnection.Close();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            login form = new login();
            form.Show();
        }
    }
    }

