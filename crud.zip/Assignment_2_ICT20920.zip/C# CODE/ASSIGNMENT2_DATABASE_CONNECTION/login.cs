﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ASSIGNMENT2_DATABASE_CONNECTION
{
    public partial class login : Form
    {
        SqlConnection sqlConnection = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=local_db_connect;Integrated Security=True");

        public login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            sqlConnection.Open();
            string username = textBox1.Text;
            string password = textBox2.Text;
            string query = "select * from user_details where USERNAME=@USERNAME and PASSWORD=@PASSWORD";
            SqlCommand cmd = new SqlCommand(query, sqlConnection);
            cmd.Parameters.AddWithValue("@USERNAME", username);
            cmd.Parameters.AddWithValue("@PASSWORD", password);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                MessageBox.Show("Login Successful ");

                welcome f1 = new welcome();
                f1.Show();
            }

            else
            {
                MessageBox.Show("Invalid UserName or Password", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show("Access Denied!!");

            }
            reader.Close();
            sqlConnection.Close();
            Hide();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }
    }
}